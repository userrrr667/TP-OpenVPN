# TP – OpenVPN sur pfSense

<aside>

**Objectif** : permettre à un poste situé à l'extérieur (côté WAN) de se connecter au LAN de l'entreprise à travers un tunnel VPN chiffré, avec OpenVPN installé sur pfSense.

</aside>

## Contexte et adressage

On reprend l'infrastructure du [**TP PfSense / DMZ**](https://app.notion.com/p/TP-PfSense-DMZ-3f2a8131b7e4809696e3f4561cbf6572?pvs=21) (même VM pfSense, mêmes IP).

- pfSense WAN (vtnet0, vmbr0) : 192.168.20.174/24 en DHCP
- pfSense LAN (vtnet1, vmbr1) : 192.168.10.5/24
- pfSense DMZ / OPT1 (vtnet2, vmbr2) : 192.168.30.254/24
- Client Windows 11 du LAN : 192.168.10.10/24, passerelle 192.168.10.5
- Réseau du tunnel VPN : 10.0.8.0/24 (réseau choisi pour le VPN, il ne doit pas exister ailleurs)
- Client VPN : une machine côté WAN (réseau 192.168.20.0/24), par exemple une VM avec sa carte sur vmbr0

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image.png)

## 1. Créer l'autorité de certification (CA) ✅

**Où** : System > Certificates (ou Cert. Manager selon la version) > onglet Authorities > Add

- Descriptive name : `CA-OpenVPN` (nom affiché dans pfSense)
- Method : Create an internal Certificate Authority (pfSense crée sa propre autorité)
- Common Name : `CA-OpenVPN` (nom inscrit dans le certificat)
- Le reste par défaut > Save

**Pourquoi** : OpenVPN authentifie le serveur et les clients avec des certificats. La CA signe ces certificats : comme le serveur et le client sont signés par la même CA, ils se font confiance.

formulaire de création de la CA

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%201.png)

 CA-OpenVPN dans la liste des Authorities

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%202.png)

## 2. Créer le certificat du serveur ✅

**Où** : System > Certificates > onglet Certificates > Add/Sign

- Method : Create an internal Certificate
- Descriptive name : `Cert-Serveur-OpenVPN`
- Certificate authority : `CA-OpenVPN` (c'est elle qui signe ce certificat)
- Common Name : `Cert-Serveur-OpenVPN`
- Certificate Type : **Server Certificate** (indique que ce certificat sert à identifier le serveur VPN)
- Le reste par défaut > Save

**Pourquoi** : c'est la « carte d'identité » du serveur VPN. Le client vérifie ce certificat pour être sûr de se connecter au bon serveur.

**Résultat** : le certificat `Cert-Serveur-OpenVPN` apparaît dans la liste des Certificates avec le type Server Certificate (Server : Yes) et l'émetteur (Issuer) `CA-Openvpn`, la CA créée à l'étape 1. Il est valable 10 ans.

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%203.png)

## 3. Créer l'utilisateur VPN et son certificat ✅

**Où** : System > User Manager > onglet Users > Add

- Username : `uservpn`
- Password : un mot de passe (à retenir, il sera demandé à la connexion VPN)
- Cocher **Click to create a user certificate**
    - Descriptive name : `Cert-uservpn`
    - Certificate authority : `CA-OpenVPN`
- Save

**Pourquoi** : on a choisi un VPN avec double authentification : le client doit avoir le certificat **et** connaître l'identifiant / mot de passe. Si l'un des deux est volé, ça ne suffit pas.

création de l'utilisateur uservpn avec la case certificat cochée

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%204.png)

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%205.png)

## 4. Installer le paquet d'export client ✅

**Où** : System > Package Manager > onglet Available Packages

- Rechercher `openvpn-client-export` > Install > Confirm
- Attendre le message de succès

**Pourquoi** : ce paquet génère automatiquement un installeur OpenVPN déjà configuré (certificats + adresse du serveur) pour le client. Sans lui, il faudrait copier les fichiers à la main.

<aside>
⚠️

pfSense doit avoir accès à Internet par son WAN 

</aside>

 openvpn-client-export installé

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%206.png)

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%207.png)

## 5. Créer le serveur OpenVPN ✅

**Où** : VPN > OpenVPN > onglet Servers > Add

- Server mode : **Remote Access (SSL/TLS + User Auth)** (certificat + identifiant/mot de passe, comme expliqué à l'étape 3)
- Backend for authentication : Local Database (les utilisateurs créés dans User Manager)
- Device mode : tun (le VPN transporte des paquets IP, mode routé)
- Protocol : UDP on IPv4 only (UDP est le protocole par défaut d'OpenVPN, plus rapide)
- Interface : WAN (le serveur écoute du côté extérieur)
- Local port : 1194 (port standard d'OpenVPN)
- TLS Configuration : laisser Use a TLS Key coché (clé générée automatiquement, protège la négociation)
- Peer Certificate Authority : `CA-OpenVPN`
- Server certificate : `Cert-Serveur-OpenVPN`
- IPv4 Tunnel Network : `10.0.8.0/24` (adresses données aux clients dans le tunnel)
- IPv4 Local network(s) : `192.168.10.0/24` (réseau que le client VPN pourra joindre : le LAN)
- Le reste par défaut > Save

**Pourquoi** : c'est le service qui attend les connexions des clients VPN et leur donne accès au LAN.

configuration du serveur (mode, interface, port)

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%208.png)

partie certificats et réseaux tunnel/local

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%209.png)

le serveur dans la liste VPN > OpenVPN > Servers

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%2010.png)

## 6. Créer les règles de pare-feu

### 6.a Autoriser OpenVPN sur le WAN ✅

**Où** : Firewall > Rules > onglet WAN > Add

- Action : Pass
- Protocol : UDP
- Source : any
- Destination : WAN address
- Destination Port Range : OpenVPN (1194)
- Save > Apply Changes

**Pourquoi** : par défaut le WAN bloque tout ce qui entre. Cette règle laisse passer uniquement les connexions VPN vers pfSense.

règle WAN UDP 1194 :

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%2011.png)

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%2012.png)

### 6.b Autoriser le trafic dans le tunnel ✅

**Où** : Firewall > Rules > onglet OpenVPN > Add

- Action : Pass
- Protocol : Any
- Source : any
- Destination : LAN subnets
- Save > Apply Changes

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%2013.png)

**Pourquoi** : une fois connecté, le trafic du client arrive par l'interface OpenVPN. Sans règle, il serait bloqué et le client ne pourrait pas joindre le LAN.

### 6.c Ne plus bloquer les réseaux privés sur le WAN ✅

**Où** : Interfaces > WAN

- Décocher **Block private networks and loopback addresses**
- Save > Apply Changes

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%2014.png)

**Pourquoi** : notre « extérieur » est le réseau de l'école 192.168.20.0/24, qui est un réseau privé. Avec cette option cochée, pfSense bloquerait le client VPN avant même de lire nos règles.

### 7.a Installer OpenVPN sur le client (côté WAN) ✅

- Copier l'installeur sur la machine côté WAN et l'exécuter
- Lancer OpenVPN GUI > clic droit sur l'icône près de l'horloge > Connect
- Saisir `uservpn` et son mot de passe

fenêtre de connexion OpenVPN

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%2015.png)

icône OpenVPN verte = connecté

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%2016.png)

### 7.b Tester la connexion ✅

- Sur le client : `ipconfig` → une carte OpenVPN avec une IP en 10.0.8.x doit apparaître
- Sur le client : `ping 192.168.10.5` → pfSense répond par le LAN à travers le tunnel
- Sur le client : ouvrir `https://192.168.10.5` → la page de connexion pfSense s'affiche
- Sur pfSense : Status > OpenVPN → `uservpn` apparaît comme connecté

<aside>
💡

Un ping vers le Windows 11 du LAN (192.168.10.10) peut échouer même si le VPN marche : le pare-feu Windows bloque les pings entrants par défaut. C'est pour ça qu'on teste vers pfSense.

</aside>

 ipconfig avec l'IP 10.0.8.x

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%2017.png)

ping 192.168.10.5 

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%2018.png)

Status > OpenVPN avec le client connecté

![image.png](TP%20%E2%80%93%20OpenVPN%20sur%20pfSense/image%2019.png)

**Résultat** : dans Status > OpenVPN, `uservpn` est connecté avec la Real Address **192.168.20.148** (le client vient bien du réseau de l'école, donc de l'extérieur, côté WAN), la Virtual Address **10.0.8.2** (son IP dans le tunnel) et le chiffrement **AES-256-GCM**. Le client accède au LAN (192.168.10.5) à travers le tunnel.

## Conclusion

Le serveur OpenVPN installé sur pfSense fonctionne : un poste situé à l'extérieur (réseau 192.168.20.0/24, côté WAN) se connecte au LAN de l'entreprise à travers un tunnel chiffré (AES-256-GCM). L'accès est sécurisé par une double authentification : le certificat de l'utilisateur, signé par notre autorité de certification, et son identifiant / mot de passe. Côté pare-feu, seul le port UDP 1194 est ouvert sur le WAN, et les clients VPN n'ont accès qu'au LAN.

---

<aside>

Ressource : [vidéo YouTube fournie](https://youtu.be/QDaRpaIH4GE)

</aside>